/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Digite o primeiro valor: ");
        double n1 = entrada.nextDouble();
        System.out.println("Digite o segundo numero: ");
        double n2 = entrada.nextDouble();
        double p = n1*n2;
        System.out.println("produto: "+ p);
    }
    
}
