/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio14 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        double a,b,d;
        System.out.println("Primeiro numero: ");
        a = ent.nextDouble();
        System.out.println("Segundo numero: ");
        b = ent.nextDouble();
        if(a>b){
            System.out.println(a/b);
        }else if(b>a){
            System.out.println(b/a);
        }else{
            System.out.println("Os numeros sao iguais!!!");
        }
    }
    
}


