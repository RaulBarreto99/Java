/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        double l;
        System.out.println("Digite o valor de um lado do quadrado: ");
        l = ent.nextDouble();
        l = l*l;
        System.out.println("o valor da area do quadrado é: "+ l);
    }
    
}
