/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        double l,r,q,c,z;
        System.out.println("Digite o valor R: ");
        r = ent.nextInt();
        System.out.println("Digite o valor L: ");
        l = ent.nextInt();
        q = l*l;
        z = 3.14*r;
        c = z*z;
        if(q>c){
            System.out.println("Quadrado é maior");
        }else if(c>q){
            System.out.println("Circulo é maior");
        }else{
            System.out.println("Sao de mesmo tamanho ");
        }
    }
    
}
