/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        double a, b, c, qa, qb, qc, qd, qe, qf;
        System.out.println("Digite o valor de 'A': ");
        a = ent.nextDouble();
        System.out.println("Digite o valor de 'B': ");
        b = ent.nextDouble();
        System.out.println("Digite o valor de 'C': ");
        c = ent.nextDouble();
        
        qa = (a/2)*c;
        qb = 3.14159 * (c*c);
        qc = (a+b)*c;
        qd = b*b;
        qe = a*b;
        qf = (a+b)*2;
        
        System.out.println(qa);
        System.out.println(qb);
        System.out.println(qc);
        System.out.println(qd);
        System.out.println(qe);
        System.out.println(qf);
    }
    
}
