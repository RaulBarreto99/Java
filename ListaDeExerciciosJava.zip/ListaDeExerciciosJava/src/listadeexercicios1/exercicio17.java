/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio17 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int a,b,c,d,scd,sab;
        System.out.println("numero A: ");
        a = ent.nextInt();
        System.out.println("numero B: ");
        b = ent.nextInt();
        System.out.println("numero C: ");
        c = ent.nextInt();
        System.out.println("numero D: ");
        d = ent.nextInt();
        scd = c+d;
        sab = a+b;
        if((b>c)&&(d>a)&&(scd>sab)&&(c>=0)&&(d>=0)&&((a%2) == 0)){
            System.out.println("Valores aceitos");
        }else{
            System.out.println("Valores não aceitos");
        }
    }
}
