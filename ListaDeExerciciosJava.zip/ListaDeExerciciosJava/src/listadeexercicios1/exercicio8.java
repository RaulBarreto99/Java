/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        double n1,n2,n3,n4,m;
        System.out.println("Digite a primeira nota:");
        n1 = ent.nextDouble();
        System.out.println("Digite a segunda nota:");
        n2 = ent.nextDouble();
        System.out.println("Digite a terceira nota:");
        n3 = ent.nextDouble();
        System.out.println("Digite a quarta nota:");
        n4 = ent.nextDouble();
        m = (n1+n2+n3+n4)/4;
        System.out.println("media: "+m);
    }
    
}
