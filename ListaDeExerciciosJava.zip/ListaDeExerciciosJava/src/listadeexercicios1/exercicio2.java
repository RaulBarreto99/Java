/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double b, e, p;
        System.out.println("Digite o valor da base:");
        b = entrada.nextInt();
        System.out.println("Digite o valor do expoente:");
        e = entrada.nextInt();
        p = Math.pow(b, e);
        System.out.println("a potencia é: "+ p);
    }
    
}
