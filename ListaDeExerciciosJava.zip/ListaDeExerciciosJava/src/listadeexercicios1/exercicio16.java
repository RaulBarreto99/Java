/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio16 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int hi,hf,c,r;
        System.out.println("Hora inicial: ");
        hi = ent.nextInt();
        System.out.println("Hora final: ");
        hf = ent.nextInt();
        if(hi>hf){
            c = 24 - hi;
            r = c+hf;
            System.out.println("Jogou durante "+r+" horas");
        }else{
            r = hf - hi;
            System.out.println("Jogou durante "+r+" horas");
    }
}
}
