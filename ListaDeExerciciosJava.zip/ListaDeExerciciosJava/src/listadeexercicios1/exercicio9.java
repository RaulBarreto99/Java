/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        double nc, nh, v, s;
        System.out.println("Numero de cadastro: ");
        nc = ent.nextDouble();
        System.out.println("Horas trabalhadas: ");
        nh = ent.nextDouble();
        System.out.println("Valor que recebe por hora: ");
        v = ent.nextDouble();
        s = nh * v;
        System.out.println("Funcionario: "+nc);
        System.out.println("Salario: "+s);
    }
    
}
