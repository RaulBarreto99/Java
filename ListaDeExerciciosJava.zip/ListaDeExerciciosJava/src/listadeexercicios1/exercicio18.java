/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio18 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int n1,n2,n3,a=0,b=0,c=0;
        System.out.println("Primeiro numero: ");
        n1 = ent.nextInt();
        System.out.println("Segundo numero: ");
        n2 = ent.nextInt();
        System.out.println("Terceiro numero: ");
        n3 = ent.nextInt();
        if(((n1>n2)&&(n1>n3)&&(n2>n3)) || ((n1>n2)&&(n2==n3))){
            a = n1;
            b = n2;
            c = n3;
        }else if((n1>n2)&&(n1>n3)&&(n3>n2)){
          a = n1;
            b = n3;
            c = n2;  
        }else if((n2>n1)&&(n2>n3)&&(n1>n3) || ((n2>n1)&&(n1==n3))){
           a = n2;
           b = n1;
           c = n3;
        }else if((n2>n1)&&(n2>n3)&&(n3>n1)){
            a = n2;
            b = n3;
            c = n1;
        }else if((n3>n1)&&(n3>n2)&&(n1>n2) || ((n3>n1)&&(n1==n2))){
            a = n3;
            b = n1;
            c = n2;
        }else if((n3>n1)&&(n3>n2)&&(n2>n1)){
            a = n3;
            b = n2;
            c = n1;
        }
        System.out.println(a+" "+" "+b+" "+c);
        if(a >= (b+c)){
            System.out.println("NÃO FORMA TRIANGULO");
        }
        if((a*a) == ((b*b)+(c*c))){
            System.out.println("TRIANGULO RETANGULO");
        }
        if((a*a) > ((b*b)+(c*c))){
            System.out.println("TRIANGULO OBTUSANGULO");
        }
        if((a*a) < ((b*b)+(c*c))){
            System.out.println("TRIANGULO ACUTANGULO");
        }
        if(a==b && a==c){
            System.out.println("TRIANGULO EQUILATERO");
        }
        if((a==b && a!=c) || (a==c && a!=b) || (b==c && b!=a) ){
            System.out.println("TRIANGULO ISOSCELES");
        }
            
    }
}
