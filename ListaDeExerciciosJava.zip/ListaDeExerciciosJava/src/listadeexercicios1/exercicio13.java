/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio13 {

    /**
     * @param args
     */
    public static void main(String[] args) {
        
        Scanner ent = new Scanner(System.in);
        double a,b,c;
        System.out.println("Primeiro numero: ");
        a = ent.nextDouble();
        System.out.println("Segundo numero: ");
        b = ent.nextDouble();
        System.out.println("Terceiro numero: ");
        c = ent.nextDouble();
        
        if(a>b && a>c){
            System.out.println("O primeiro numero Ã©  maior");
        }else if(b>a && b>c){
            System.out.println("O segundo numero Ã©  maior");
        }else if(c>a && c>b){
            System.out.println("O terceiro numero Ã© o maior");
        }else{
            System.out.println("Existem 2 valores mais altos com o mesmo valor");
        }
    }

    }
    

