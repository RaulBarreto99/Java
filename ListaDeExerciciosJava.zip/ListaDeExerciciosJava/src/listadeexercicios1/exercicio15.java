/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio15 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        double a,b,c,delta, x1,x2,raiz;
        System.out.println("Valor de A:");
        a = ent.nextDouble();
        System.out.println("Valor de B:");
        b = ent.nextDouble();
        System.out.println("Valor de C:");
        c = ent.nextDouble();
        delta = (b*b-4)*a*c;
        //raiz = Math.sqrt(delta);
       // System.out.println("dddddd"+delta);
        if(delta < 0){
        System.out.println("Impossivel calcular");
    }else{
        x1 = (- b + Math.sqrt(delta)/(2*a));
        x2 = (- b - Math.sqrt(delta)/(2*a));
            System.out.println("X1:"+x1+" X2:"+x2);
    }
    }

}
