/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios1;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        double a,b,h,c;
        System.out.println("Digite o lado A do triangulo: ");
        a = ent.nextDouble();
        System.out.println("Digite o lado B do triangulo: ");
        b = ent.nextDouble();
        c = (a*a)+(b*b);
        h = Math.sqrt(c);
        System.out.println("Raiz: "+h);
    }
    
}
