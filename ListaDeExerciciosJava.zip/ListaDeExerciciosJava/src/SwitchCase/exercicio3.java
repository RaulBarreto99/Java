/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SwitchCase;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio3 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int valor,n = 0,z=0,h=0,t=0,q=0,j=0;
        
        System.out.print("Digite o valor desejado: ");
        valor = ent.nextInt();
        do{
            if(valor >= 100){
                n = 100;
                valor = valor-100;
                
            }else if(valor >= 50){
                n = 50;
                valor = valor-50;
               
            }else if (valor>=10){
                n = 10;
                valor = valor-10;
                
            }else if(valor>=5){
                n = 5;
                valor = valor-5;
                
            }else if(valor>=1){
                n = 1;
                valor = valor-1;
               
            }
            else{}
            switch(n){
                case 100:
                    z = z+1;
                    break;
                case 50:
                    h=h+1;
                    break;
                case 10:
                    t=t+1;
                    break;
                case 5:
                    q=q+1;
                    break;
                case 1:
                    j=j+1;
                    break;
                   
            }
        }while(valor != 0);
        
        if(z>0){
            System.out.println(z+" notas de 100");
        }
       if(h>0){
            System.out.println(h+" notas de 50");
        }
       if(t>0){
            System.out.println(t+" notas de 10");
        }
       if(q>0){
            System.out.println(q+" notas de 5");
        }
       if(j>0){
            System.out.println(j+" notas de 1");
        }
    }
}
