/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SwitchCase;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio1 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int n,d;
        String c;
        System.out.print("Digite o numero: ");
        n = ent.nextInt();
        d = n%3;
        if(d == 0){
            c = "a";
        }else{
            c = "b";
        }
        switch(c){
            case "a":
                System.out.print("O numero é divisivel por 3");
                break;
            case "b":
                System.out.print("O numero não é divisivel por 3");
                break;
        }
        
        
    }
}
