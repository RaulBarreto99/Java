/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SwitchCase;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio6 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        String dia;
        System.out.print("Digite o numero do dia da semana: ");
        dia = ent.next();
        switch(dia){
            case "1":
                System.out.println("Fim de semana");
                break;
            case "2":
                System.out.println("Dia de semana");
                break;
                case "3":
                System.out.println("Dia de semana");
                break;
                case "4":
                System.out.println("Dia de semana");
                break;
                case "5":
                System.out.println("Dia de semana");
                break;
                case "6":
                System.out.println("Dia de semana");
                break;
                case "7":
                System.out.println("Fim de semana");
                break;
                default:
                    System.out.println("Dia invalido");
        }
    }
}
