/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SwitchCase;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio8 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        String mes;
        double cont, fevereiro, marco,abril, maio, junho, julho, agosto, setembro,outubro, novembro, dezembro;
        System.out.print("Digite o mês de pagamento: ");
        mes = ent.next();
        System.out.println("Valor da anuidade: ");
        cont = ent.nextInt();
        
        fevereiro = cont + ((cont*5)/100);
        marco = fevereiro + ((fevereiro*5)/100);
        abril = marco + ((marco*5)/100);
        maio = abril + ((abril*5)/100);
        junho = abril + ((abril*5)/100);
        julho = junho + ((junho*5)/100);
        agosto = julho + ((julho*5)/100);
        setembro = agosto + ((agosto*5)/100);
        outubro = setembro + ((setembro*5)/100);
        novembro = outubro + ((outubro*5)/100);
        dezembro = novembro + ((novembro*5)/100);
        switch(mes){
            case "janeiro":
                System.out.println("Valor a ser pago: "+cont);
                break;
                case "fevereiro":
                    System.out.println("Valor a ser pago: "+fevereiro);
                    break;
                    case "marco":                   
                    System.out.println("Valor a ser pago: "+marco);
                    break;
                    case "abril":                   
                    System.out.println("Valor a ser pago: "+abril);
                    break;
                    case "maio":                   
                    System.out.println("Valor a ser pago: "+maio);
                    break;
                    case "junho":                   
                    System.out.println("Valor a ser pago: "+junho);
                    break;
                    case "julho":                   
                    System.out.println("Valor a ser pago: "+julho);
                    break;
                    case "agosto":                   
                    System.out.println("Valor a ser pago: "+agosto);
                    break;
                    case "setembro":                   
                    System.out.println("Valor a ser pago: "+setembro);
                    break;
                    case "outubro":                   
                    System.out.println("Valor a ser pago: "+outubro);
                    break;
                    case "novembro":                   
                    System.out.println("Valor a ser pago: "+novembro);
                    break;
                    case "dezembro":                   
                    System.out.println("Valor a ser pago: "+dezembro);
                    break;
        }
    }
}
