/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SwitchCase;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio7 {
    public static void main(String[] args) {
        int valorFixo = 100, idade, soma;
        String cont="0";
        Scanner ent = new Scanner(System.in);
        System.out.print("Idade: ");
        idade = ent.nextInt();
        if(idade<10){
            cont = "10";
        }else if(idade>=10&&idade<=30){
            cont = "10e30";
        }else if(idade>=40&&idade<60){
            cont = "40e60";
        }else if(idade>60){
            cont = "60";
        }
            
        switch(cont){
            case "10":
                soma = valorFixo+80;
                System.out.println("valor a pagar: "+soma);
                break;
                case "10e30":
                soma = valorFixo+50;
                System.out.println("valor a pagar: "+soma);
                break;
                case "40e60":
                soma = valorFixo+95;
                System.out.println("valor a pagar: "+soma);
                break;
                case "60":
                soma = valorFixo+130;
                System.out.println("valor a pagar: "+soma);
                break;
        }
    }
}
