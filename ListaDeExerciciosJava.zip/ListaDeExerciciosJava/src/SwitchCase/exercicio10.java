/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SwitchCase;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio10 {

    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int n1, n2,soma;
        String c;
        System.out.print("Digite um numero: ");
        n1 = ent.nextInt();
        System.out.print("Digite o segundo numero: ");
        n2 = ent.nextInt();
        System.out.print("Digite a operação desejada: ");
        c = ent.next();
        
        switch (c){
                case"+":
                   soma = n1+n2;
                    System.out.println("Resultado: "+soma);
                    break;
                    case"-":
                   soma = n1-n2;
                    System.out.println("Resultado: "+soma);
                    break;
                    case"*":
                   soma = n1*n2;
                    System.out.println("Resultado: "+soma);
                    break;
                    case"/":
                   soma = n1/n2;
                    System.out.println("Resultado: "+soma);
                    break;
                    default:
                        System.out.println("Digito invalido");
                    
        } 
    }
}
