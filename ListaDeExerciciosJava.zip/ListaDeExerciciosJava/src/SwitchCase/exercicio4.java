/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SwitchCase;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio4 {

    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int ano;
        String bissexto = "nao", mes;
        System.out.print("Digite o ano: ");
        ano = ent.nextInt();
        System.out.print("Digite o mês: ");
        mes = ent.next();

        if ((ano % 400) == 0) {
            bissexto = "sim";
        } else if ((ano % 4) == 0) {
            if ((ano % 100 != 0)) {
                bissexto = "sim";
            }
        }else{}

        switch (mes) {
            case "janeiro":
                System.out.print(mes + " tem 31 dias");
                break;
            case "fevereiro":
                switch (bissexto) {
                    case "sim":
                        System.out.println(mes + " tem 29 dias");
                        break;
                    case "nao":
                        System.out.println(mes + " tem 28 dias");
                        break;
                }
                break;
            case "março":
                System.out.print(mes + " tem 31 dias");
                break;
            case "abril":
                System.out.print(mes + " tem 30 dias");
                break;
            case "maio":
                System.out.print(mes + " tem 31 dias");
                break;
            case "junho":
                System.out.print(mes + " tem 30 dias");
                break;
            case "julho":
                System.out.print(mes + " tem 31 dias");
                break;
            case "agosto":
                System.out.print(mes + " tem 31 dias");
                break;
            case "setembro":
                System.out.print(mes + " tem 30 dias");
                break;
            case "outubro":
                System.out.print(mes + " tem 31 dias");
                break;
            case "novembro":
                System.out.print(mes + " tem 30 dias");
                break;
            case "dezembro":
                System.out.print(mes + " tem 31 dias");
                break;
        }
    }
}
