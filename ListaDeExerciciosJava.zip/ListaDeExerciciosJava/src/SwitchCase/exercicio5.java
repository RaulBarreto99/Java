/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SwitchCase;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio5 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        String mes;
        System.out.print("Digite o mês: ");
        mes = ent.next();
        
        switch (mes) {
            case "janeiro":
                System.out.print(mes + " Alta temporada ");
                break;
            case "fevereiro":
                System.out.print(mes + " Alta temporada ");
                break;
            case "marco":
                System.out.print(mes + " Baixa temporada ");
                break;
            case "abril":
                System.out.print(mes + " Baixa temporada ");
                break;
            case "maio":
                System.out.print(mes + " Baixa temporada ");
                break;
            case "junho":
                System.out.print(mes + " Alta temporada ");
                break;
            case "julho":
                System.out.print(mes + " Alta temporada ");
                break;
            case "agosto":
                System.out.print(mes + " Baixa temporada ");
                break;
            case "setembro":
                System.out.print(mes + " Baixa temporada ");
                break;
            case "outubro":
                System.out.print(mes + " Baixa temporada ");
                break;
            case "novembro":
                System.out.print(mes + " Baixa temporada ");
                break;
            case "dezembro":
                System.out.print(mes + " Alta temporada ");
                break;
        }
    }
}
