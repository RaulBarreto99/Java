/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SwitchCase;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio9 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        String cpf,v;
        char n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11;
        int soma,soma2,d1,d2;
        System.out.print("Digite seu CPF: ");
        cpf = ent.next();
        n1 = cpf.charAt(0);
        n2 = cpf.charAt(1);
        n3 = cpf.charAt(2);
        n4 = cpf.charAt(3);
        n5 = cpf.charAt(4);
        n6 = cpf.charAt(5);
        n7 = cpf.charAt(6);
        n8 = cpf.charAt(7);
        n9 = cpf.charAt(8);
        n10 = cpf.charAt(9);
        n11 = cpf.charAt(10);
        
        soma = (n1*10)+(n2*9)+(n3*8)+(n4*7)+(n5*6)+(n6*5)+(n7*4)+(n8*3)+(n9*2);
        d1 = 11-(soma%11);
        if(d1<10){
            if(d1 == n10){
                v = "y";
            }else{
                v = "n";
        }
    } else if(d1>=10){
            if(d1==0){
                v = "y";
        }else{
                v = "n";
            }
        }else{
        
        soma2 = (n1*11)+(n2*10)+(n3*9)+(n4*8)+(n5*7)+(n6*6)+(n7*5)+(n8*4)+(n9*3)+(n10*2);
        d2 = 11-(soma%11);
        if(d2<10){
            if(d2 == n11){
                v = "y";
            }else{
                v = "n";
        }
    } else{
            if(d2==0){
                v = "y";
        }else{
                v = "n";
            }
    }
        
}
        switch(v){
            case "y":
                System.out.println("CPF valido");
                break;
            case "n":
                System.out.println("CPF invalido");
                break;
        }
}
}