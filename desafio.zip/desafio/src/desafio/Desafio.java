/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desafio;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class Desafio {
    static Scanner ent = new Scanner(System.in);
    
    public static void main(String[] args) {
        int resp = 0;
        int[][]matriz = populaMatriz(criaMatriz());
        do{
        switch(menu()){
            case 1:
                somaLinha(matriz);
                imprime(matriz);
            break;
            
            case 2:
                somaColuna(matriz);
                imprime(matriz);
            break;
            
            case 3:
                somaDiagonalPrincipal(matriz);
                imprime(matriz);
            break;
            
            case 4:
                somaDiagonalSecundaria(matriz);
                imprime(matriz);
            break;
            
            case 5:
                quadradoMagico(matriz, somaLinha(matriz), somaColuna(matriz), somaDiagonalPrincipal(matriz), somaDiagonalSecundaria(matriz));
                imprime(matriz);
            break;
            
            case 6:
                int[][] invertida = inverter(matriz);
                imprime(invertida);
            break;
            
            case 7:
                maior(matriz);
                imprime(matriz);
            break;
            
            case 8: 
                menor(matriz);
                imprime(matriz);
            break;
            
            default:
                System.out.println("opção invalida!!!");           
        }
            System.out.println("voltar ao menu? (1)sim: ");
            resp = ent.nextInt();
        }while(resp == 1);
    }
    
    static int[][]criaMatriz(){
        System.out.println("digite um numero para ser o numero de linhas e colunas da matriz: ");
        int tamanho = ent.nextInt();
        int[][]matriz = new int[tamanho][tamanho];
        return matriz;   
    }
    
    static int[][]populaMatriz(int[][]matriz){
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.println("digite um valor: ");
                matriz[i][j] = ent.nextInt();
            }
        }
        return matriz;
    }
    
    static int somaLinha(int[][]matriz){
        int soma = 0;
        for (int i = 0; i < matriz.length; i++) {
            soma = 0;
            for (int j = 0; j < matriz[i].length; j++) {
                soma += matriz[i][j];
            }
            System.out.println("soma linha "+i+": "+soma);
        }
        return soma;
    }
    
    static int somaColuna(int[][]matriz){
        int soma = 0;
        for (int i = 0; i < matriz.length; i++) {
            soma = 0;
            for (int j = 0; j < matriz[i].length; j++) {
                soma += matriz[j][i];
            }
            System.out.println("soma coluna "+i+": "+soma);
        }
        return soma;
    }
    
    static int somaDiagonalPrincipal(int[][]matriz){
        int soma = 0;
        for (int i = 0; i < matriz.length; i++) {
                soma += matriz[i][i];
            
        }
        System.out.println("soma diagonal principal: "+soma);
        return soma;
    }
    
    static int somaDiagonalSecundaria(int[][]matriz){
        int soma = 0, l = matriz.length;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                if(i+j == matriz.length - 1){
                    soma += matriz[i][j];
                }
            }
        }    
            System.out.println("soma diagonal secundaria: "+soma);
        return soma;
    }
    
    static void quadradoMagico(int[][]matriz, int somaLinha, int somaColuna, int diagonalPrincipal, int diagonalSecundaria){
        if((somaLinha == somaColuna) && (somaColuna == diagonalPrincipal) && (diagonalPrincipal == diagonalSecundaria)){
            System.out.println("A matriz é um quadrado magico ");
        }else{
            System.out.println("Não é um quadrado magico ");
        }
    }
    
    static int[][]inverter(int[][]matriz){
        int[][] matriz1 = new int[matriz.length][matriz.length];
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz1[j][i] = matriz[i][j];
            }
        }
        return matriz1;
    }
    
    static int maior(int[][]matriz){
        int maior = 0;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                if(matriz[i][j] > maior){
                    maior = matriz[i][j];
                }
            }
        }
        System.out.println("maior: "+maior);
        return maior;
    }
    
     static int menor(int[][]matriz){
        int menor = 0;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                if(matriz[i][j] < menor){
                    menor = matriz[i][j];
                }
            }
        }
        System.out.println("menor: "+menor);
        return menor;
    }
     
     static int menu(){
         System.out.println("(1) Somar as linhas da matriz \n" +
                            "(2) somar as colunas da matriz \n" +
                            "(3) Somar a diagonal principal da matriz \n" +
                            "(4) Somar a diagonal secundária da matriz \n" +
                            "(5) Testar se a matriz é um quadrado mágico (Pesquisar)\n" +
                            "(6) Inverter a Matriz \n" +
                            "(7) Identificar o maior valor da matriz \n" +
                            "(8) Identificar o menor valor da matriz  ");
         System.out.println("");
         System.out.println("O que deseja fazer ?: ");
         int opcao = ent.nextInt();
         return opcao;
     }
     
     static void imprime(int[][]matriz){
         for (int i = 0; i < matriz.length; i++) {
             for (int j = 0; j < matriz[i].length; j++) {
                 System.out.println("matriz ["+i+"]["+j+"] = "+matriz[i][j]);
             }
         }
     }
}
