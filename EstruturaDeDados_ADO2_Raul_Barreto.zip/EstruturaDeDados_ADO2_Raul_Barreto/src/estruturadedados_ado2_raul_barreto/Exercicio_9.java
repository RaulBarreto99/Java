/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estruturadedados_ado2_raul_barreto;

/**
 *
 * @author raul.barreto
 */
public class Exercicio_9 {

    public static void main(String[] args) {
        int[] vetor = {5, 6, 2, 7, 9, 1, 8, 3, 7};
        int[] vetor2 = rearanjaVetor(vetor);
        imprimeVetor(vetor2);
    }

    public static int[] rearanjaVetor(int[] vetor) {
        int indice = vetor[0];
        int maior = vetor.length - 1;
        int i = 0;
        int menor = 0;
        int[] vetor2 = new int[vetor.length];

        while (i < vetor.length) {
            if (vetor2[i] == 0) {
                vetor2[i] = indice;
            }

            if (vetor[i] < indice) {
                vetor2[menor] = vetor[i];
                menor++;
            } else if (vetor[i] > indice) {
                vetor2[maior] = vetor[i];
                maior--;
            }
            i++;
        }
        return vetor2;
    }

    public static void imprimeVetor(int[] vetor) {
        for (int i = 0; i < vetor.length; i++) {
            System.out.print(vetor[i] + ", ");
        }
    }
}
