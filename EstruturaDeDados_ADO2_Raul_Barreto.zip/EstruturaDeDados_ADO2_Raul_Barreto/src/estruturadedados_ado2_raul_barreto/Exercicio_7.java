/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estruturadedados_ado2_raul_barreto;

/**
 *
 * @author raul.barreto
 */
public class Exercicio_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] vetor = {1, 2, 3, 4, 5};
        int[] vetor2 = {5, 6, 7, 8, 9};
        imprimeSemDuplicatas(vetor, vetor2);

    }

    public static void imprimeSemDuplicatas(int[] vetor, int[] vetor2) {
        int cont = 0;
        int cont2 = 0;
        int a = 0;
        int i = 0;

        while (i < vetor.length) {
            if (cont2 > vetor2.length - 1) {
                cont2 = 0;
                cont++;
                i++;
                a = 0;
            } else if (vetor[cont] != vetor2[cont2]) {
                if (cont2 == vetor2.length - 1 && a == 0) {
                    System.out.print(vetor[cont] + ", ");
                }
                cont2++;
            } else {
                cont2 = vetor2.length;
                a = 1;
            }

        }
    }
}
