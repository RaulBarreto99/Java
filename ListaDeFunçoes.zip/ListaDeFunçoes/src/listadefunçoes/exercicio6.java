/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadefunçoes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio6 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int a, b, c,d;
        
        System.out.print("Valor de A:");
        a = ent.nextInt();
        System.out.print("Valor de B:");
        b = ent.nextInt();
        System.out.print("Valor de C:");
        c = ent.nextInt();
        System.out.print("(1)- maior raiz"
                + "(2) - menor raiz");
        d = ent.nextInt();
        double saida = maiorRaiz(a, b, c, d);
        System.out.println(saida);
    }

    public static double maiorRaiz(double a, double b, double c, int d) {
        double x1, x2, r=0, delta;
        delta = (b * b - 4) * a * c;
        if (delta < 0) {
            r = -1;
        } else {
            x1 = (-b + Math.sqrt(delta) / (2 * a));
            x2 = (-b - Math.sqrt(delta) / (2 * a));
            if (x1 > x2) {
                if(d==1){
                    r=x1;
                }else if(d==2){
                    r=x2;
                }
            } else if (x2 > x1) {
                if(d==1){
                    r=x2;
                }else if(d==2){
                    r=x1;
                }
            } else {
                r = x1;
            }
        }
        return r;
    }
}
