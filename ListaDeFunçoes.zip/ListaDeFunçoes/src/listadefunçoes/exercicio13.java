/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadefunçoes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio13 {
    static Scanner ent = new Scanner(System.in);
    public static void main(String[] args) {
        int a = entrada();
        divi(a);
    }
    
    static int entrada(){
        int numero;
        System.out.print("numero: ");
        numero = ent.nextInt();
        return numero;
    }
    
    static void divi(int numero){
        int r;
        System.out.println("o numero "+numero+" é divisivel por:");
        for (int i = 1; i <= numero; i++) {
            if(numero % i == 0){
                System.out.println(i);
            }
        }
    }
}
