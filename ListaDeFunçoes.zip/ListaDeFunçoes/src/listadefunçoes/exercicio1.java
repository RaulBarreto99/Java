/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadefunçoes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio1 {
    public static void main(String[] args) {
        int n1,n2,n3;
        Scanner ent = new Scanner(System.in);
        System.out.print("primeiro numero: ");
        n1 = ent.nextInt();
        System.out.print("segundo numero: ");
        n2 = ent.nextInt();
        System.out.print("terceiro numero: ");
        n3 = ent.nextInt();
        int r = menor(n1,n2,n3);
        System.out.println("o numero "+r+" é o menor");
        
    }

   static int menor (int a, int b,int c ){
       int m=0;
        if(a<b && a<c){
            m = a;
        }else if(b<a && b<c){
            m = b;
        } else if(c<a && c<b){
            m = c;
        }
        return m;
}
}