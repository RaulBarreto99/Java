/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadefunçoes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio3 {
    
    static int fatorial(int n){
        int cont = n,fat=1;
        for (int i = 1; i <= cont; i++) {
            fat = fat*i;
        }
        return fat;
    }
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        System.out.print("Numero: ");
        int n = ent.nextInt();
        int resp = fatorial(n);
        System.out.println("resultado: "+resp);
    }
}
