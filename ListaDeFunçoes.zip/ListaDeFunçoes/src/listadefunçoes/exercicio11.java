/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadefunçoes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio11 {
    static Scanner ent = new Scanner(System.in);
    public static void main(String[] args) {
        double a = 0;
        System.out.println("categoria: "+conceito(entrada(a)));
    }
    
    static double entrada(double media){
        System.out.print("media doa aluno: ");
        media = ent.nextInt();
        return media;
}
    
    static String conceito(double idade){
        String retorno;
        if(idade >= 0 && idade <= 4.9){
            retorno = "D";
        }else if(idade >= 5 && idade <=6.9){
            retorno = "C";
        }else if(idade >= 7 && idade <=8.9){
            retorno = "B";
        }else if(idade >= 9 && idade <= 10){
            retorno = "A";
        }else {
            retorno = "media invalida!!";
        }
        return retorno;
    }
}
