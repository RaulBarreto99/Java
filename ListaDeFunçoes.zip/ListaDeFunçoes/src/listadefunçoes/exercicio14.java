/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadefunçoes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio14 {
   static Scanner ent = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.print("valor inicial: ");
        int a = ent.nextInt();
        System.out.print("total de somas: ");
        int n = ent.nextInt();
        int saida = somatoria(a, n);
        System.out.println("resultado: "+saida);
    }
    
    static int somatoria (int a, int n){
    int cont=1,resp=a,numero=a+1;
    while(cont < n ){
        resp = resp+numero;
        numero++;
        cont++;
    }
        return resp;
    }
}
