/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadefunçoes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio9 {
    static Scanner ent = new Scanner(System.in);
    
    public static void main(String[] args) {
        int anos, meses, dias;
        System.out.println("digite sua idade em anos, meses e dias\n"
                + "exemplo:\n"
                + "anos: 17\n"
                + "meses: 4\n"
                + "dias: 21\n");
        System.out.println("=========================================");
        System.out.print("anos: ");
        anos = ent.nextInt();
        System.out.print("meses: ");
        meses = ent.nextInt();
        System.out.print("dias: ");
        dias = ent.nextInt();
        
        
        mostrar(idade(anos, meses, dias));
    }
    static int idade (int anos, int meses, int dias){
        int a,m,d,soma;
        a = anos*365;
        m = meses*30;
        d = dias*1;
        soma = a+m+d;
        return soma;
    }
    
    static void mostrar(int soma){
        System.out.println("voce tem "+soma+" dias de vida");
    }
}
