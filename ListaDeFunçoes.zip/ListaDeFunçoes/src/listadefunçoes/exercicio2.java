/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadefunçoes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio2 {
    
    static int somatoria (int n){
    int cont=1,resp=0;
    while(cont <= n ){
        resp = resp + cont;
        cont++;
    }
        return resp;
    }
    
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        System.out.print("Numero: ");
        int n = ent.nextInt();
        int saida = somatoria(n);
        System.out.println("resultado: "+saida);
    }
}
