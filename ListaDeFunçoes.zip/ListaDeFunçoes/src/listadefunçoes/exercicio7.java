/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadefunçoes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio7 {
        public static void main(String[] args) {
    Scanner ent = new Scanner(System.in);
    double r,saida;
    System.out.print("digite o raio: ");
    r = ent.nextDouble();
    saida = raio(r);
            System.out.println("o volume é: "+saida);
    }
        static double raio(double r){
            double v;
            v = ((4/3)*3.14*(r*r*r));
            return v;
        }
}
