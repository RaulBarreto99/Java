/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadefunçoes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio15 {
    static Scanner ent = new Scanner(System.in);
    
    public static void main(String[] args) {
        System.out.print("numero: ");
        int x = ent.nextInt();
        System.out.print("potencia: ");
        int z = ent.nextInt();
        int saida = potenciacao(x, z);
        System.out.println("resultado: "+saida);
}
    
    static int potenciacao(int x, int z){
        int a=x;
        for (int i = 0; i < z; i++) {
            x = x*a;
        }
        return x;
    }
}
