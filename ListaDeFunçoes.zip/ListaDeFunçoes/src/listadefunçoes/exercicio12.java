/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadefunçoes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio12 {
    static Scanner ent = new Scanner(System.in);
    static double altura,sexo;
    public static void main(String[] args) {
        entrada();
        double a = pesoIdeal(altura, sexo);
        mostrar(a);
    }
    
    static void entrada(){
        System.out.print("altura: ");
        altura = ent.nextDouble();
        System.out.print("(1) - masculino\n"
                + "(2) - feminino\n"
                + "digite: ");
        sexo = ent.nextDouble();
    }
    
    static double pesoIdeal(double altura, double sexo){
        double peso=0;
        if(sexo == 1){
            peso = 72.7 * altura - 58;
        }else if(sexo == 2){
            peso = 62.1 * altura - 44.7;
        }else if(sexo != 1 && sexo != 2){
            peso = 3;
        }
        return peso;
    }
    
    static void mostrar(double peso){
        if(peso == 3){
            System.out.println("sexo invalido");
        }else{
        System.out.println("Seu peso ideial é: "+peso+"kg");
    }
}
}
