/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadefunçoes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio10 {
    static Scanner ent = new Scanner(System.in);
    public static void main(String[] args) {
        int a = 0;
        a = entrada(a);
        System.out.println("categoria: "+categoria(a));
    }
    
    static int entrada(int idade){
        System.out.print("digite sua idade: ");
        idade = ent.nextInt();
        return idade;
}
    
    static String categoria(int idade){
        String retorno;
        if(idade >= 5 && idade <=7){
            retorno = "infantil A";
        }else if(idade >= 8 && idade <=10){
            retorno = "infantil B";
        }else if(idade >= 11 && idade <=13){
            retorno = "juvenil A";
        }else if(idade >= 14 && idade <= 17){
            retorno = "juvenil B";
        }else{
            retorno = "adulto";
        }
        return retorno;
    }
    
}