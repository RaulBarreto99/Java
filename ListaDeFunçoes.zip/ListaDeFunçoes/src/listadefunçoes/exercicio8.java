/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadefunçoes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio8 {
    static Scanner ent = new Scanner(System.in);
    
   
    static int entradaDados( int z ){
        
        System.out.print("Digite um valor: ");
        z = ent.nextInt();
        
        return z;
    }
    
    static void Primos (boolean primo, int valor){
        System.out.print("valor: "+valor+" primo: ");
        
            primo = ehPrimo( valor );
            mostrarPrimo( primo, valor );
        
    }
    

    static boolean ehPrimo( int x ){
        boolean sim=false;
        int cont=0;
        
        for(int i=1; i <= x; i++){
            if(x%i == 0){
                cont++;
            }
        }
        
        if(cont == 2){
            sim = true;
        }

        return sim;
    }
    
     
    static void mostrarPrimo( boolean x, int i ){
        if (x == false){
            System.out.println(x);
        } else {
            System.out.println(x); 
        } 
    }
    
    
    
    public static void main(String[] args) {
        int a = 0;
        boolean y = false;
        
        a = entradaDados(a);
        
        Primos(y, a);
        
    }   
}
