/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listamatrizes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio33 {
    static Scanner ent = new Scanner(System.in);
    
    static int[][]criaMatriz(){
        System.out.print("digite o numero de linhas da matriz: ");
        int linhas = ent.nextInt();
        System.out.print("digite o numero de colunas da matriz: ");
        int colunas = ent.nextInt();
        int[][]matriz = new int[linhas][colunas];
        
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("digite um numero: ");
                matriz[i][j]=ent.nextInt();
            }
        }
        return matriz;
    }
   
    
    static void imprime(int[][]matriz){
     for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                if(matriz[i][j] < 0){
                    System.out.println("matriz["+(i+1)+"]["+(j+1)+" = "+matriz[i][j]);
                }
            }
        }
    }
    
    public static void main(String[] args) {
        int[][] matriz = criaMatriz();
        imprime(matriz);
    }
}
