/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listamatrizes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio39 {
    static Scanner ent = new Scanner(System.in);
    static int colunas;
    static int[][]criaMatriz(){
        System.out.print("digite o numero de linhas da matriz: ");
        int linhas = ent.nextInt();
        System.out.print("digite o numero de colunas da matriz: ");
        colunas = ent.nextInt();
        int[][]matriz = new int[linhas][colunas];
        
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("digite um numero: ");
                matriz[i][j]=ent.nextInt();
            }
        }
        return matriz;
    }
    
    static int[][]criaMatriz2(){
        System.out.print("digite o numero de colunas da segunda matriz: ");
        int coluninha = ent.nextInt();
        
        int[][]matriz = new int[colunas][coluninha];
        
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("digite um numero: ");
                matriz[i][j]=ent.nextInt();
            }
        }
        return matriz;
    }
    
    static int produto(int[][]matriz){
        int produto=1;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                produto = produto * matriz[i][j];
            }
        }
        return produto;
    }
    
    static void imprime(int produto1, int produto2){
        System.out.println("produto matriz 1: "+produto1);
        System.out.println("produto matriz 2: "+produto2);
    }
    
    public static void main(String[] args) {
        int[][]matriz = criaMatriz();
        int[][]matriz2 = criaMatriz2();
        int produto = produto(matriz);
        int produto2 = produto(matriz2);
        imprime(produto, produto2);
    }
}
