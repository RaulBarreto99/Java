/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listamatrizes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio29 {
    static Scanner ent = new Scanner(System.in);
    
    static int[][]criaMatriz(){
        System.out.print("digite o numero de linhas da matriz: ");
        int linhas = ent.nextInt();
        System.out.print("digite o numero de colunas da matriz: ");
        int colunas = ent.nextInt();
        int[][]matriz = new int[linhas][colunas];
        
        return matriz;
    }
    
    static int [] criaVetor(int[][]matriz){
       int [] vetor = new int[matriz[0].length];
       for (int i = 0; i < vetor.length ; i++) {
           System.out.print("Digite um valor: ");
           vetor[i] = ent.nextInt();
          
       }
       return vetor;
   } 
    
    static int[][]populaMatriz(int[][]matriz, int[]vetor){
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz[i][j] = vetor[j];
            }
        }
        return matriz;
    }
    
    static void imprime(int[][]matriz){
     for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.println("matriz["+(i+1)+"]["+(j+1)+"] = "+matriz[i][j]);
            }
        }
    }
    
    public static void main(String[] args) {
        int[][]matriz = criaMatriz();
        int[]vetor = criaVetor(matriz);
        int[][]matriz2 = populaMatriz(matriz, vetor);
        imprime(matriz2);
    }
}
