/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listamatrizes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio36 {
    static Scanner ent = new Scanner(System.in);
    
    static int[][]criaMatriz(){
        System.out.print("digite o numero de linhas e colunas da matriz: ");
        int tamanho = ent.nextInt();
        int[][]matriz = new int[tamanho][tamanho];
        
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("digite um numero: ");
                matriz[i][j]=ent.nextInt();
            }
        }
        return matriz;
    }
    
    static void diagonalPrincipal(int[][]matriz){
        int j = 0;
        for (int i = 0; i < matriz.length; i++) {
            System.out.println("ELEMENTOS DA DIAGONAL PRINCIPAL");
            System.out.println("matriz["+(i+1)+"]["+(j+1)+"] = "+matriz[i][j]);
            j++;
        }
    }
    
    public static void main(String[] args) {
        diagonalPrincipal(criaMatriz());
    }
}
