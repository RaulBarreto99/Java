/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listamatrizes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio37 {
    static Scanner ent = new Scanner(System.in);
    
    static int[][]criaMatriz(){
        System.out.print("digite o numero de linhas da matriz: ");
        int linhas = ent.nextInt();
        System.out.print("digite o numero de colunas da matriz: ");
        int colunas = ent.nextInt();
        int[][]matriz = new int[linhas][colunas];
        
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("digite um numero: ");
                matriz[i][j]=ent.nextInt();
            }
        }
        return matriz;
    }
    
    static int linhasNulas(int[][]matriz){
        int nulas = 0,cont = 0;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                nulas = nulas + matriz[i][j];
                if(nulas == 0){
                    cont++;
                }
            }    
        }
        return cont;
    }
    
    static int colunasNulas(int[][]matriz){
        int nulas = 0,cont = 0;
        for (int i = 0; i < matriz[i].length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                nulas = nulas + matriz[j][i];
                if(nulas == 0){
                    cont++;
                }
            }    
        }
        return cont;
    }
    
    static void imprime(int linhas, int colunas){
        System.out.println(linhas+" linhas nulas");
        System.out.println(colunas+" colunas nulas");
    }
    
    public static void main(String[] args) {
        int[][]matriz = criaMatriz();
        int linhas = linhasNulas(matriz);
        int colunas = colunasNulas(matriz);
        imprime(linhas, colunas);
    }
}
