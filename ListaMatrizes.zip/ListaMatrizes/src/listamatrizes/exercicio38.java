/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listamatrizes;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio38 {
    static Scanner ent = new Scanner(System.in);
    
    static int[][]criaMatriz(){
        System.out.print("digite o numero de linhas e colunas da matriz: ");
        int tamanho = ent.nextInt();
        int[][]matriz = new int[tamanho][tamanho];
        
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("digite um numero: ");
                matriz[i][j]=ent.nextInt();
            }
        }
        return matriz;
    }
    
    static void imprime(int[][]matriz){
        int cont=0;
        int i = 0;
        while(i < matriz.length){
            int col = 1;
            col = col + cont;
        while(col < matriz.length) {
            System.out.println(matriz[i][col]);
            col++;
        }
        cont++;
        i++;
        }
    }
    
    public static void main(String[] args) {
        imprime(criaMatriz());
    }
}
