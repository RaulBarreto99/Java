/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algoritimos2;

/**
 *
 * @author raul.barreto
 */
public class questao5 {
    static int[] parInpar(int[]vetor){
        int aux = 0, par=0, impar = vetor.length -1;
        for (int i = 0; i < vetor.length;) {
            if(vetor[i]%2 != 0){
                System.out.println("sx: "+impar);
               aux = vetor[8];
               vetor[8] = vetor[i];
               vetor[i] = aux;
               impar--;
            }
            else i++;
        }
        for (int i = 0; i < vetor.length; i++) {
            System.out.println("vetor: "+vetor);
        }
        return vetor;
    }
    public static void main(String[] args) {
        int[] vetor = {5, 10, 3, 2, 4, 7, 9, 8, 5};
        parInpar(vetor);
        
    }
}
