/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algoritimos2;

/**
 *
 * @author raul.barreto
 */

/*Dado um vetor de n números inteiros, faça uma função para determinar
o comprimento de um segmento crescente de comprimento máximo.
Exemplos: na sequência
{ 5, 10, 3, 2, 4, 7, 9, 8, 5} o comprimento do segmento crescente máximo
é 4 {2, 4, 7, 9}.
na sequência
{10, 8, 7, 5, 2} o comprimento de um segmento crescente máximo é 1.
A função deve ter deve ter no máximo n passos, ou seja, o tamanho do
vetor
*/
public class questao4 {
    public static void main(String[] args) {
        int[]vetor = {5, 10, 3, 2, 4, 7, 9, 8, 5};
        comprimento(vetor);
    }
    static void comprimento(int[]vetor){
        int cont = 0;
        int sequencia = vetor[0];
        for (int i = 1; i < vetor.length; i++) {
            if(vetor[i] > sequencia){
                cont++;
                sequencia = vetor[i];
            }else{
                sequencia = vetor[i];
            }
        }
        if(cont == 0) cont =1;
        System.out.println("cont: "+cont);
    }
}
