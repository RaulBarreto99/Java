/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algoritimos2;

/**
 *
 * @author raul.barreto
 */

/*Escreva o algoritmo que recebe um vetor A de tamanho n contendo
 inteiros e encontra um par de elementos distintos a e b do vetor que
 fazem com que a diferença absoluta a-b seja a maior possível. A função
 deve ter deve ter no máximo n passos, ou seja, o tamanho do vetor V[]
 */
public class Questao3 {
    public static void main(String[] args) {
        int[]vetor = {1,4,3,9,0};
        maiorDifereca(vetor);
    }
    static void maiorDifereca(int[] vetor) {
        int a = vetor[0], b = vetor[0];
        for (int i = 0; i < vetor.length; i++) {
            if (vetor[i] < a) a = vetor[i];
            if (vetor[i] > b) b = vetor[i];
        }
        System.out.println("posiçoes com maior diferença: "+a+" e "+b);
    }
}
