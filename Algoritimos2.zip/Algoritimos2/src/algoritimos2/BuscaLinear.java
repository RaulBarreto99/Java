/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algoritimos2;

/**
 *
 * @author raul.barreto
 */
public class BuscaLinear {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[]vetor = {1,2,3,4,5};
        int x = 2;
        System.out.println("numero se enconta na posição: "+linear(vetor, x));
    }
    
    static int linear(int[]vetor, int x){
        int t = 0;
        while(t < vetor.length){ 
            if(vetor[t] == x) return t+1;
            t++;
        }
            return -1;   
        }
}
