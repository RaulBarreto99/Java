/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algoritimos2;

/**
 *
 * @author raul.barreto
 */
public class BuscaBinaria {
    public static void main(String[] args) {
        int[]vetor = {1,2,3,4,5};
        int x = 2;
        System.out.println("numero se enconta na posição: "+binaria(vetor, x));
    }
    
    static int binaria(int[]vetor, int x){
        int i = 0, f = vetor.length, m;
        while(i <= f){
            m = (i+ f) /2;
            if(vetor[m] == x) return m;
            if(x < vetor[m]) f = m - 1;
            if(x > vetor[m]) i = m+1;
        }
        return -1;
    }
}
