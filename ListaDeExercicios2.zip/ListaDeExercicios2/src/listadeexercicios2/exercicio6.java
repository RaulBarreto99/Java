/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios2;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio6 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        String nome,sexo,n=null,s=null;
        int idade,i=0,cont=1;
        do{
        System.out.print("Nome: ");
        nome = ent.next();
        System.out.print("Idade: ");
        idade = ent.nextInt();
        System.out.print("Sexo: ");
        sexo = ent.next();
        if(idade>i){
            i=idade;
            n=nome;
            s=sexo;
        }
        cont++;
        }while(cont<=5);
        System.out.println("Aluno mais velho:"+n+" "+i+" "+s);
                
    }
}
