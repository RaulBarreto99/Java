/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios2;

/**
 *
 * @author Raul
 */
public class exercicio7 {
    public static void main(String[] args) {
        int cont=0,n=0;
        while(cont<=200){
            if(n%7==0){
            System.out.println(n);
            }
            n++;
            cont++;
        }
    }
}
