/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios2;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio9 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        double n1,media=0,r,q;
        int cont=1;
        String nome;  
        System.out.print("Quantidade de alunos: ");
        q = ent.nextInt();
        while(cont<=q){
        System.out.print("Nome: ");
        nome = ent.next();
        System.out.print("1ºnota: ");
        n1 = ent.nextDouble();
        media = media+n1;
        cont++;
        }
        r = media/q;
        System.out.println("Media da sala: "+r);
    }
}
