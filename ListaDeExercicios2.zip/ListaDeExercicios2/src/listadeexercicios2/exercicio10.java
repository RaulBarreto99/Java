/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios2;


/**
 *
 * @author Raul
 */
public class exercicio10 {
    public static void main(String[] args) {
        double soma=0,t;
        for(double cont=1;cont<=20;cont++){
            t = 1/cont;
            soma=soma+t;
        }
        System.out.println("S = "+soma);
    }
}
