/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios2;

/**
 *
 * @author Raul
 */
import java.util.Scanner;
public class exercicio2 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in); 
        int n,soma=0,r,cont=1;
        System.out.print("Numero: ");
        n = ent.nextInt();
        while(cont<=n){
            soma = soma+cont;
            cont++;
        }
        r=soma;
        System.out.println("Resultado: "+r);
        
    }
}
