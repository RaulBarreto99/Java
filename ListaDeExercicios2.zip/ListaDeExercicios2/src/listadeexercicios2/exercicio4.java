/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios2;

/**
 *
 * @author Raul
 */
public class exercicio4 {
    public static void main(String[] args) {
        for(int n=10;n<=1000;n=n+10){
            System.out.println(n);
    }
}
}