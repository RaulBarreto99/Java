/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios2;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio20 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int saldo,deposito,saque,operacao=1;
        System.out.print("Saldo: ");
        saldo = ent.nextInt();
        do{
        System.out.println("Saque digite 1:\n"
                + "Deposito digite 2:\n"
                + "Sair digite 3:");
        operacao = ent.nextInt();
        switch(operacao){
            case 1:
                System.out.print("digite o valor do saque: ");
                saque = ent.nextInt();
                saldo = saldo - saque;
                System.out.println("Saldo = "+saldo);
                break;
                case 2:
                System.out.print("digite o valor do deposito: ");
                deposito = ent.nextInt();
                saldo = saldo + deposito;
                System.out.println("Saldo = "+saldo);
                break;
                default:
                    if(saldo == 0){
                        System.out.println("CONTA ZERADA");
                    }else if(saldo < 0 ){
                        System.out.println("CONTA ESTOURADA");
                    }else {
                        System.out.println("CONTA PREFERENCIAL");
                    }
        }       
        }while(operacao == 1 || operacao==2);
    }
}
