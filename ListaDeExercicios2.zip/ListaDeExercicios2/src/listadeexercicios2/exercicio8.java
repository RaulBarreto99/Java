/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios2;

/**
 *
 * @author Raul
 */
public class exercicio8 {
    public static void main(String[] args) {
        double media=0,divisor=0,r;
        for(int cont=13;cont<=73;cont++){
            if(cont%2==0){
                media = media+cont;
                divisor++;
        }else{}
        
        }
            r = media/divisor;
            System.out.println("Media: "+r);
            
    
}
}