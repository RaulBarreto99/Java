/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios2;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio21 {

    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int n, p = 0;
        System.out.print("Digite um numero: ");
        n = ent.nextInt();
        for (int cont = 1; cont <= n; cont++) {
            if (n % cont == 0 && cont != n) {

                p = p + cont;
            }

        }
        if (p == n) {
            System.out.println("numero perfeito");
        } else {
            System.out.println("numero não perfeito");
        }
    }
}
