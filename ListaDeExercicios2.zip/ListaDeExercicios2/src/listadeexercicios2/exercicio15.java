/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios2;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio15 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int n,fat=1,cont;
        System.out.print("Digite um numero: ");
        n = ent.nextInt();
        cont = n;
        for (int i = 0; i < cont; i++) {
            System.out.println("nnnn"+n);
            fat = fat*n;
            System.out.println("ccc"+fat);
            n--;
        }
        System.out.println("Resultado: "+fat);
    }
}
