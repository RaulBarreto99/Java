/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios2;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio13 {
     public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        double soma=0,t=1,n,a=1;
        System.out.println("Digite o numero denominador final: ");
        n = ent.nextDouble();
        for(double cont=1;cont<=n;cont++){
            t = t*cont;
            System.out.println("t"+t);
            soma=soma+(t/a);
            a = a+2;
        }
        System.out.println("S = "+soma);
    }
}
