/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios2;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class exercicio18 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int n,n1=1,n2=2,r;
        System.out.print("Digite um numero: ");
        n = ent.nextInt();
        System.out.println("0\n"+n1+"\n"+n1+"\n"+n2);
        for (int cont = 1; cont <= n; cont++) {
            if(cont%2!=0){
                r=n1+n2;
                n1=r;
            }else{
              r=n1+n2;
              n2=r;
              
            }
            System.out.println(r);
        }
    }
}
