/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadeexercicios2;

/**
 *
 * @author Raul
 */
public class exercicio5 {
    public static void main(String[] args) {
        for(int n=100;n>=1;n = n-1){
            if(n%2==0){
                System.out.println(n);
            }
        }
    }
}
